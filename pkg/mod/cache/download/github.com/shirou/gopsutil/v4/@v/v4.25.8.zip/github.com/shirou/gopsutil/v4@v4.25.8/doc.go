// SPDX-License-Identifier: BSD-3-Clause
package gopsutil
